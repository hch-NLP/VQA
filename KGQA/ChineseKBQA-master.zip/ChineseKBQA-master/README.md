# ChineseKBQA
In you use this dataset, please cite the following paper:

@inproceedings{duan2016nlpcc,
  title={Overview of the NLPCC-ICCPOL 2016 Shared Task: Open Domain Chinese Question Answering},
  author={Nan Duan},
  booktitle={NLPCC/ICCPOL},
  year={2016}
}
