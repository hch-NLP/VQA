
### Download and extract the following resources:

-   [GloVe vectors](http://nlp.stanford.edu/data/glove.6B.zip)
-   [Pre-trained data](https://filebox.ece.vt.edu/~jiasenlu/codeRelease/vqaRelease/train_only/data_train_val.zip)
-   [Annotations for validation set](http://visualqa.org/data/mscoco/vqa/Annotations_Val_mscoco.zip)
-   [Model Weights](https://drive.google.com/file/d/0B3b69xdtpDT8U2dwajNKOEhUWUU/view?usp=sharing)
