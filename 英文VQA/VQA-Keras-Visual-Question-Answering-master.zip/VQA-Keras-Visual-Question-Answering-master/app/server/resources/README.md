### Resources for Server
Copy the following resources here:
 - `data_img.h5` from root `data/` folder
 - `data_prepro.json` from root `data/` folder
 - model_weights

