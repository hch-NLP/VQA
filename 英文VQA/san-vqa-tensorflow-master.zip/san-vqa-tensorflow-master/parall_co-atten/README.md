# Implementation of parallel method in paper Hierarchical Question-Image Co-Attention for Visual Question Answering (https://arxiv.org/pdf/1606.00061.pdf) on tensorflow
#### just using hierarchical feature of question level and word level (instead of full method mentioned in paper) 
#### tensorflow version 0.10.0


#### Data preparing is same as way in master
#### Training and testing
```
$ python model_wqv.py 
```

